---
description: This is a demo child page
hidden: true
title: page 4
---

This is a demo child page, not displayed in the menu