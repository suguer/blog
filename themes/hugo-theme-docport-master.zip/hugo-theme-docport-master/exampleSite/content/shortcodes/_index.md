---
date: "2017-04-24T18:36:24+02:00"
description: ""
hide:
- toc
title: Shortcodes
weight: 30
---

A bunch of Shortcodes are available with this theme :

{{%children style="card" description="true" %}}
