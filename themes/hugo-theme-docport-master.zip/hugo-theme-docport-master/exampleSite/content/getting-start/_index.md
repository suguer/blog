---
alwaysopen: true
date: "2020-08-20T16:42:11.812Z"
description: Getting started
head: <hr/>
hide:
- toc
post: "&nbsp;\U0001F44B"
title: Getting started
weight: 2
---

## Requirements

Download [Hugo binary](https://gohugo.io/overview/installing/) for your OS (Windows, Linux, Mac) : it’s that simple

{{%children style="h2" description="true"%}}
