---
type: raw
title: Content Manager
url: /admin/index.html
---
<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
</head>
<body>
  <!-- Include the script that builds the page and powers Netlify CMS -->
  <script src="https://unpkg.com/netlify-cms@^2.0.0/dist/netlify-cms.js"></script>
  <script src="./shortcode/alert.js"></script>
  <script src="./shortcode/expand.js"></script>
  <script src="./shortcode/panel.js"></script>
  <script src="./shortcode/button.js"></script>
</body>
</html>
