---
subpage: true
title: Disable features
---

You can disable feature in docport by changing some params in `config.toml`


## Hide Next Page Chevrons

![](chevrons.png?classes=border,shadow)

```toml
	[params]
	disableNavChevron = true
```
