---
hidden: true
ignoresearch: true
---

The name of the application: {{<c/text "app_name*" />}}


A brief description:
{{<c/text "app_description*" multi >}}
Lorem placeholder
{{</c/text>}}


What frameworks (if any) does this application require?
{{<c/text "app_frameworks*" />}}