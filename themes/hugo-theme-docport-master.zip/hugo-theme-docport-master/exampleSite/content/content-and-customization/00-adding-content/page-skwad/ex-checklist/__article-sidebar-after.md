---
---

<div class="checklist-footer">
	<button type="button" 
	onclick="skwad.saveDocumentAsFile(skwad.form.getAttribute('ref'));"
	class="btn btn-success"><i class="fas fa-download"></i>&nbsp;Download Answers</button>
</div>

{{%notice info%}}
This checklist was made from the VSAQ Vendor Security Assessment Questionnaire, licensed with Apache License 2.0 -- More info here : https://github.com/google/vsaq
{{%/notice %}}

