---
date: "2017-04-24T18:36:24+02:00"
hidden: true
revealOptions:
  center: true
  controls: true
  history: false
  progress: true
  transition: concave
theme: league
title: My Slide ! fullscreen
type: slide
---

# In the morning

___

## Getting up

- Turn off alarm
- Get out of bed

___

## Breakfast

- Eat eggs
- Drink coffee

---

# In the evening

___

## Dinner

- Eat spaghetti
- Drink wine

___

## Going to sleep

- Get in bed
- Count sheep