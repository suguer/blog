---
description: ""
hide:
  - toc
title: Navigation & Search
weight: 30
---

Docport allow you to easily customize header, left & righ sidebars and footer.

Some placeHolders and entry points location exists to embed custom content, without modification of the theme.

{{%notice success%}}
These custom contents could be full HTML or Markdown files.
{{%/notice %}}

{{%children style="h2" %}}

![footer](screenshot.png?classes=border,shadow)
