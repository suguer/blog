---
title: "{{ replace .TranslationBaseName "-" " " | title }}"
date: {{ .Date }}
description: ""
draft: true

subpage: false

hide:
- header
- nav
- breadcrumb
- footer
- nextpage
---

Lorem Ipsum.
Notice `draft` is set to true.
